"""Generate a synthetic patient dataset for Health360 (no real patient data)."""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 3000

age = np.clip(rng.normal(48, 16, N), 18, 90).round().astype(int)
gender = rng.choice(["Male", "Female"], N)
bmi = np.clip(rng.normal(27.5, 5.5, N), 15, 50).round(1)
systolic_bp = np.clip(rng.normal(95 + age * 0.45, 14), 90, 200).round().astype(int)
cholesterol = np.clip(rng.normal(170 + age * 0.6, 35), 110, 330).round().astype(int)
glucose = np.clip(rng.normal(85 + (bmi - 22) * 1.8 + age * 0.25, 22), 65, 300).round().astype(int)
smoker = rng.choice(["Yes", "No"], N, p=[0.22, 0.78])
alcohol = np.clip(rng.poisson(3, N) + (smoker == "Yes") * rng.poisson(2, N), 0, 30)
exercise = np.clip(rng.normal(3.5, 2.2, N), 0, 14).round(1)
fatigue = rng.choice(["Yes", "No"], N, p=[0.3, 0.7])
chest_pain = rng.choice(["Yes", "No"], N, p=[0.12, 0.88])
dizziness = rng.choice(["Yes", "No"], N, p=[0.15, 0.85])

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

smk = (smoker == "Yes").astype(int)
heart_p = sigmoid(-7 + 0.045*age + 0.012*(cholesterol-200) + 0.015*(systolic_bp-120) + 0.8*smk - 0.08*exercise + 0.03*(bmi-25))
diab_p = sigmoid(-8 + 0.025*age + 0.07*(bmi-25) + 0.03*(glucose-100) - 0.06*exercise)
stroke_p = sigmoid(-8.5 + 0.05*age + 0.02*(systolic_bp-120) + 0.7*smk + 0.02*alcohol)

df = pd.DataFrame({
    "patient_id": [f"P{str(i).zfill(5)}" for i in range(1, N+1)],
    "age": age, "gender": gender, "bmi": bmi,
    "systolic_bp": systolic_bp, "cholesterol": cholesterol, "glucose": glucose,
    "smoker": smoker, "alcohol_units_week": alcohol, "exercise_hours_week": exercise,
    "fatigue": fatigue, "chest_pain": chest_pain, "dizziness": dizziness,
    "heart_disease": (rng.random(N) < heart_p).astype(int),
    "diabetes": (rng.random(N) < diab_p).astype(int),
    "stroke": (rng.random(N) < stroke_p).astype(int),
})
df.to_csv("data/raw_patients.csv", index=False)
print("Saved data/raw_patients.csv", df.shape)
