"""Clean raw data and add derived fields for Tableau."""
import pandas as pd

df = pd.read_csv("data/raw_patients.csv").drop_duplicates("patient_id").dropna()

df["age_group"] = pd.cut(df["age"], [17, 29, 44, 59, 74, 120],
                         labels=["18-29", "30-44", "45-59", "60-74", "75+"])
df["bmi_category"] = pd.cut(df["bmi"], [0, 18.5, 25, 30, 100],
                            labels=["Underweight", "Normal", "Overweight", "Obese"])
df["bp_category"] = pd.cut(df["systolic_bp"], [0, 120, 130, 140, 300],
                           labels=["Normal", "Elevated", "High Stage 1", "High Stage 2"])
df["disease_count"] = df[["heart_disease", "diabetes", "stroke"]].sum(axis=1)

# Simple transparent risk score (0-100)
score = (
    (df["age"] / 90) * 20
    + ((df["bmi"] - 18).clip(0, 25) / 25) * 15
    + ((df["systolic_bp"] - 90).clip(0, 90) / 90) * 15
    + ((df["cholesterol"] - 120).clip(0, 200) / 200) * 15
    + ((df["glucose"] - 70).clip(0, 200) / 200) * 15
    + (df["smoker"] == "Yes") * 10
    + (df["chest_pain"] == "Yes") * 5
    + (df["dizziness"] == "Yes") * 2.5
    + (df["fatigue"] == "Yes") * 2.5
)
df["risk_score"] = score.round(1)
df["risk_level"] = pd.cut(df["risk_score"], [-1, 35, 50, 100], labels=["Low", "Medium", "High"])

df.to_csv("data/health360_clean.csv", index=False)
print(df["risk_level"].value_counts())
print("Saved data/health360_clean.csv", df.shape)
