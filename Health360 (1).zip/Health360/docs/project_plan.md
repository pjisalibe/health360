# Project Plan (Epics -> Tasks)
1. Data Collection & Extraction: generate/collect dataset, validate schema
2. Data Preparation: clean, handle nulls, create age/BMI/BP groups, risk score
3. Data Visualization: build 9 worksheets
4. Dashboards: Clinical, Lifestyle, Population dashboards with filters
5. Story: 4-point narrative
6. Performance Testing: check load time, optimise with extracts
7. Web Integration: embed Tableau Public iframe in a web page / README link
8. Demonstration & Documentation: README, screenshots, demo video, GitHub upload
