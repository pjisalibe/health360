# Tableau Dashboard Build Guide

## 1. Connect data
Connect -> Text file -> `data/health360_clean.csv`.
Set `age_group`, `bmi_category`, `bp_category`, `risk_level` as Dimensions (strings).

## 2. Calculated fields
- **Total Patients**: `COUNT([patient_id])`
- **High Risk %**: `SUM(IF [risk_level]="High" THEN 1 ELSE 0 END) / COUNT([patient_id])`
- **Disease Prevalence %**: `SUM([heart_disease]) / COUNT([patient_id])` (repeat for diabetes, stroke)
- **Any Disease**: `IF [disease_count] > 0 THEN "Yes" ELSE "No" END`

## 3. Worksheets
1. KPI tiles: Total Patients, High Risk %, Avg BMI, Avg BP, Avg Cholesterol, Avg Glucose
2. Disease prevalence by age_group (bar, one measure per disease)
3. Disease prevalence by bmi_category (stacked bar)
4. Smoking vs disease (side-by-side bars, colour = smoker)
5. Exercise hours vs risk_score (scatter + trend line)
6. Alcohol units vs disease prevalence (line)
7. Correlation heatmap: age_group x bmi_category, colour = AVG(risk_score)
8. Symptom analysis: fatigue / chest pain / dizziness vs disease_count
9. High-risk patient table (filter risk_level = High, sort by risk_score desc)

## 4. Dashboards
- **Clinical Risk Dashboard** (Dr. Carter): KPIs + high-risk table + BP/cholesterol/glucose views
- **Lifestyle Analysis Dashboard** (Emily): sheets 4-8
- **Population Health Dashboard** (Dr. Nair): sheets 2, 3, 7
Add filters: gender, age_group, bmi_category, smoker. Use "Use as Filter" on charts.

## 5. Story
Create a Story with 4 points: Overview -> Key risk factors -> High-risk segments -> Recommendations.

## 6. Publish
File -> Save to Tableau Public. Paste the link into README.md.
Export screenshots to a `screenshots/` folder and reference them in the README.
